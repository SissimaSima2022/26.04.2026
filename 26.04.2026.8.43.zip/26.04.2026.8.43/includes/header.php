<?php
if (!defined('BASE_URL')) { require __DIR__ . '/config.php'; }
$current_page = $_GET['page'] ?? 'home';
?>
<!DOCTYPE html>
<html lang="<?= e($T['html_lang']) ?>" dir="<?= e($T['dir']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= e($T['school_short']) ?> — <?= e($T['school_full']) ?>">
    <title><?= e($page_title ?? $T['school_short']) ?> · <?= e($T['school_full']) ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= asset('images/favicon.svg') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700;9..144,800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Cairo:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <?php if ($T['dir'] === 'rtl'): ?>
    <link rel="stylesheet" href="<?= asset('css/rtl.css') ?>">
    <?php endif; ?>
</head>
<body class="lang-<?= e($LANG) ?>" dir="<?= e($T['dir']) ?>">

<!-- ============ TOP HEADER ============ -->
<header class="top-header">
    <div class="container top-header-inner">
        <a href="<?= url('') ?>" class="logo-link">
            <div class="logo-glow"></div>
            <img src="<?= asset('images/logo.png') ?>" alt="ENSTSA" class="logo-img">
            <div class="logo-text">
                <div class="logo-name"><?= e($T['school_short']) ?></div>
                <div class="logo-sub"><?= e($T['school_full']) ?></div>
            </div>
        </a>

        <div class="flex-spacer"></div>

        <a href="https://www.google.com/maps/search/?api=1&query=Mahelma+Sidi+Abdellah+Algiers" target="_blank" rel="noopener" class="header-item header-location">
            <div class="header-icon-circle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <div class="header-text-group">
                <div class="header-label"><?= e($T['campus']) ?></div>
                <div class="header-value"><?= e($T['campus_location']) ?></div>
            </div>
        </a>

        <a href="<?= page_url('contact') ?>" class="header-item header-email">
            <div class="header-icon-circle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            </div>
            <span>contact@enstsa.edu.dz</span>
        </a>

        <a href="https://moodle.enstsa.edu.dz" target="_blank" rel="noopener" class="btn-moodle">
            <?= e($T['moodle']) ?>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        </a>

        <div class="visitor-counter">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            <div>
                <div class="visitor-label"><?= e($T['visitors']) ?></div>
                <div class="visitor-count"><?= number_format($visitor_count) ?></div>
            </div>
        </div>

        <div class="lang-switcher">
            <?php foreach (['en' => 'EN', 'fr' => 'FR', 'ar' => 'ع'] as $code => $label): ?>
                <a href="<?= e(lang_url($code)) ?>" class="lang-btn <?= $LANG === $code ? 'active' : '' ?>"><?= $label ?></a>
            <?php endforeach; ?>
        </div>
    </div>
</header>

<!-- ============ ANNOUNCEMENT RIBBON ============ -->
<div class="announcement-ribbon">
    <div class="container ribbon-inner">
        <div class="ribbon-label">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            <?= e($T['notice']) ?>
        </div>
        <div class="ribbon-marquee">
            <div class="marquee-track">
                <?php for ($loop = 0; $loop < 2; $loop++): foreach ($T['announcements'] as $ann): ?>
                    <span class="marquee-item"><span class="marquee-dot"></span><?= e($ann) ?></span>
                <?php endforeach; endfor; ?>
            </div>
        </div>
    </div>
</div>

<!-- ============ NAVIGATION ============ -->
<nav class="main-nav">
    <div class="container nav-inner">
        <a href="<?= url('') ?>" class="nav-home <?= is_current('home') ? 'active' : '' ?>"><?= e($T['nav']['home']) ?></a>

        <div class="nav-menus">
            <?php
            $nav_groups = [
                ['label' => $T['nav']['programs'], 'prefix' => 'programs', 'items' => $T['menus']['programs']],
                ['label' => $T['nav']['school'], 'prefix' => 'school', 'items' => $T['menus']['school']],
                ['label' => $T['nav']['campus'], 'prefix' => 'campus', 'items' => $T['menus']['campus']],
                ['label' => $T['nav']['student'], 'prefix' => 'student', 'items' => $T['menus']['student']],
                ['label' => $T['nav']['announcements'], 'prefix' => 'announcements', 'items' => $T['menus']['announcements']],
            ];
            foreach ($nav_groups as $group): ?>
                <div class="nav-group">
                    <button class="nav-group-btn">
                        <?= e($group['label']) ?>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="nav-dropdown">
                        <?php foreach ($group['items'] as $slug => $label): ?>
                            <a href="<?= page_url($group['prefix'] . '/' . $slug) ?>"><?= e($label) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <button class="nav-mobile-toggle" id="mobile-toggle" aria-label="Menu">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
    </div>

    <div class="nav-mobile" id="nav-mobile">
        <a href="<?= url('') ?>" class="nav-mobile-item-top"><?= e($T['nav']['home']) ?></a>
        <?php foreach ($nav_groups as $group): ?>
            <details class="nav-mobile-group">
                <summary><?= e($group['label']) ?><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg></summary>
                <div class="nav-mobile-sub">
                    <?php foreach ($group['items'] as $slug => $label): ?>
                        <a href="<?= page_url($group['prefix'] . '/' . $slug) ?>"><?= e($label) ?></a>
                    <?php endforeach; ?>
                </div>
            </details>
        <?php endforeach; ?>
    </div>
</nav>

<main>
