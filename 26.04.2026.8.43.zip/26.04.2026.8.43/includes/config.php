<?php
// ============================================================
// ENSTSA website configuration
// Works in any subdirectory (e.g. /var/www/public_html/nassima)
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Send no-cache headers for the PHP output so modifications appear immediately
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// -------- BASE URL (auto-detected, works in any subfolder) --------
$script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
if ($script === '/' || $script === '\\' || $script === '.') {
    $script = '';
}
define('BASE_URL', rtrim($script, '/'));
define('SITE_ROOT', realpath(__DIR__ . '/..'));

// -------- LANGUAGE HANDLING --------
$supported_langs = ['en', 'fr', 'ar'];

if (isset($_GET['lang']) && in_array($_GET['lang'], $supported_langs, true)) {
    $_SESSION['lang'] = $_GET['lang'];
    $redirect = strtok($_SERVER['REQUEST_URI'], '?');
    header('Location: ' . $redirect);
    exit;
}

$LANG = $_SESSION['lang'] ?? 'en';
if (!in_array($LANG, $supported_langs, true)) {
    $LANG = 'en';
}

$T = require __DIR__ . '/../lang/' . $LANG . '.php';

// -------- VISITOR COUNTER --------
$counter_file = __DIR__ . '/../data/counter.txt';
if (!file_exists(dirname($counter_file))) {
    @mkdir(dirname($counter_file), 0755, true);
}
if (!file_exists($counter_file)) {
    @file_put_contents($counter_file, '12847');
}

$visitor_count = (int) @file_get_contents($counter_file);
if (empty($_SESSION['counted'])) {
    $visitor_count++;
    @file_put_contents($counter_file, (string) $visitor_count, LOCK_EX);
    $_SESSION['counted'] = true;
}

// ============================================================
// HELPERS
// ============================================================

/** URL builder that works in any subfolder */
function url($path = '') {
    $path = ltrim($path, '/');
    return BASE_URL . '/' . $path;
}

/**
 * Build an URL for an asset (CSS/JS/image) and AUTOMATICALLY append
 * a ?v=<timestamp> based on the file's last modification time.
 * --> As soon as you replace a file on the server, visitors get the
 *     new version immediately. No more browser cache issues.
 */
function asset($path) {
    $path = ltrim($path, '/');
    $full = SITE_ROOT . '/assets/' . $path;
    $version = @file_exists($full) ? @filemtime($full) : time();
    return BASE_URL . '/assets/' . $path . '?v=' . $version;
}

/** URL for an internal page */
function page_url($page) {
    return url('index.php?page=' . urlencode($page));
}

/** URL with a language change */
function lang_url($lang) {
    return strtok($_SERVER['REQUEST_URI'], '?') . '?' . http_build_query(array_merge($_GET, ['lang' => $lang]));
}

/** HTML escape helper */
function e($v) {
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

/** Check if we are on a given page */
function is_current($page) {
    $current = $_GET['page'] ?? 'home';
    return $current === $page;
}
