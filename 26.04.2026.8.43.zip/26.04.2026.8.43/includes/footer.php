<?php /* Student stats modal removed — stats now shown in homepage section */ ?>
</main>

<footer class="site-footer">
    <div class="footer-bg"></div>
    <div class="footer-blueprint"></div>
    <div class="container footer-content">
        <div class="footer-grid">
            <div>
                <div class="footer-brand">
                    <img src="<?= asset('images/logo.png') ?>" alt="ENSTSA">
                    <div>
                        <div class="footer-brand-name">ENSTSA</div>
                        <div class="footer-brand-sub">Sidi Abdellah · Algeria</div>
                    </div>
                </div>
                <h4 class="footer-heading"><?= e($T['footer']['contact']) ?></h4>
                <div class="footer-contact-list">
                    <div class="footer-contact-item">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span><?= e($T['footer']['address']) ?></span>
                    </div>
                    <div class="footer-contact-item">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <a href="<?= page_url('contact') ?>">contact@enstsa.edu.dz</a>
                    </div>
                </div>
                <h4 class="footer-heading" style="margin-top: 1.5rem;"><?= e($T['footer']['social']) ?></h4>
                <div class="footer-social">
                    <a href="https://facebook.com" target="_blank" rel="noopener" aria-label="Facebook"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
                    <a href="https://youtube.com" target="_blank" rel="noopener" aria-label="YouTube"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33zM9.75 15.02V8.48l5.75 3.27z"/></svg></a>
                    <a href="https://linkedin.com" target="_blank" rel="noopener" aria-label="LinkedIn"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2zM4 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg></a>
                </div>
            </div>

            <div>
                <h4 class="footer-heading"><?= e($T['footer']['quick']) ?></h4>
                <ul class="footer-list">
                    <li><a href="<?= url('') ?>">→ <?= e($T['footer']['links'][0]) ?></a></li>
                    <li><a href="https://moodle.enstsa.edu.dz" target="_blank" rel="noopener">→ <?= e($T['footer']['links'][1]) ?></a></li>
                    <li><a href="https://webmail.enstsa.edu.dz" target="_blank" rel="noopener">→ <?= e($T['footer']['links'][2]) ?></a></li>
                    <li><a href="https://www.mesrs.dz" target="_blank" rel="noopener">→ <?= e($T['footer']['links'][3]) ?></a></li>
                </ul>
            </div>

            <div>
                <h4 class="footer-heading"><?= e($T['nav']['programs']) ?></h4>
                <ul class="footer-list">
                    <?php $i = 0; foreach ($T['menus']['programs'] as $slug => $label): if ($i++ >= 5) break; ?>
                        <li><a href="<?= page_url('programs/' . $slug) ?>">→ <?= e($label) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div>
                <h4 class="footer-heading"><?= e($T['footer']['news']) ?></h4>
                <p class="footer-newsletter-text"><?= e($T['footer']['news_body']) ?></p>
                <form class="newsletter-form" action="<?= url('subscribe.php') ?>" method="post">
                    <input type="email" name="email" placeholder="<?= e($T['footer']['email_ph']) ?>" required>
                    <button type="submit">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        <?= e($T['footer']['subscribe']) ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-copyright"><?= e($T['footer']['rights']) ?></div>
            <div class="footer-legal">
                <?php
                $legal_slugs = ['legal/privacy', 'legal/notice', 'legal/faq', 'legal/help'];
                foreach ($T['footer']['legal'] as $i => $lab): ?>
                    <a href="<?= page_url($legal_slugs[$i]) ?>"><?= e($lab) ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</footer>

<script src="<?= asset('js/main.js') ?>"></script>
</body>
</html>
