<?php
require __DIR__ . '/includes/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $file = __DIR__ . '/data/newsletter.txt';
        if (!is_dir(dirname($file))) @mkdir(dirname($file), 0755, true);
        @file_put_contents($file, $email . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
header('Location: ' . url(''));
exit;
