# 📘 Guide d'installation du site ENSTSA

## ✅ Qu'est-ce que ce fichier ZIP contient ?

Un site web **100 % PHP + CSS + JavaScript**, prêt à l'emploi.
- ✅ Aucun Node.js requis
- ✅ Aucun build nécessaire
- ✅ Aucune base de données
- ✅ Fonctionne dans n'importe quel sous-dossier du serveur
- ✅ Plus aucun souci de cache grâce au versionnement automatique des fichiers

## 🗂️ Structure de l'archive

Quand vous **extrayez** le ZIP, vous obtenez directement ces fichiers (PAS de sous-dossier "php-site") :

```
index.php                  ← point d'entrée principal
subscribe.php              ← traitement newsletter
.htaccess                  ← configuration Apache
INSTALLATION.md            ← ce guide
assets/
   css/                    ← styles
   js/                     ← javascript
   images/                 ← logo + photos (à remplacer par les vôtres)
data/                      ← compteur, messages, newsletter (doit être inscriptible)
includes/                  ← header / footer / config
lang/                      ← en.php, fr.php, ar.php (tous les textes)
pages/                     ← home, contact, pages génériques
```

## 🚀 Installation en 4 étapes

### Étape 1 — Vider le dossier cible sur le serveur

**TRÈS IMPORTANT** pour éviter les conflits avec d'anciens fichiers :

```bash
sudo rm -rf /var/www/public_html/nassima/*
sudo rm -rf /var/www/public_html/nassima/.[!.]*   # supprime les fichiers cachés
```

### Étape 2 — Transférer le ZIP par FileZilla

Envoyez le fichier `enstsa-php-site.zip` dans `/var/www/public_html/nassima/`.

### Étape 3 — Décompresser SANS créer de sous-dossier

Via Termius :

```bash
cd /var/www/public_html/nassima
sudo unzip -o enstsa-php-site.zip
sudo rm enstsa-php-site.zip   # on peut l'effacer après
```

Vérifiez que `index.php` est bien à la racine :

```bash
ls /var/www/public_html/nassima/
```

Vous devez voir : `index.php`, `assets`, `includes`, `lang`, `pages`, etc.
**Si vous voyez un dossier `php-site` à la place**, c'est que l'extraction a créé un sous-dossier — remontez tous les fichiers :

```bash
cd /var/www/public_html/nassima
sudo mv php-site/* php-site/.[!.]* .
sudo rmdir php-site
```

### Étape 4 — Permissions

```bash
sudo chown -R www-data:www-data /var/www/public_html/nassima
sudo chmod -R 755 /var/www/public_html/nassima
sudo chmod -R 775 /var/www/public_html/nassima/data
sudo systemctl restart apache2
```

### ✅ C'est prêt ! Ouvrez

```
http://votre-domaine/nassima/
```

## 🎨 Comment modifier le site (TRÈS important à lire)

### 💡 Grâce au versionnement automatique

Chaque fois que vous **remplacez une image** (logo, photos du carousel, etc.),
le système ajoute automatiquement un numéro de version unique basé sur la
date du fichier. **Vos visiteurs voient le changement IMMÉDIATEMENT**, sans
avoir besoin de vider leur cache. 🎉

### 📷 Changer les photos du carousel

Remplacez simplement ces 3 fichiers sur le serveur (via FileZilla) :

```
/var/www/public_html/nassima/assets/images/campus-1.jpg
/var/www/public_html/nassima/assets/images/campus-2.jpg
/var/www/public_html/nassima/assets/images/campus-3.jpg
```

**Contraintes :** format JPG, environ 1920×1080 px, moins de 500 Ko chacune.

### 🏷️ Changer le logo

Remplacez le fichier : `/var/www/public_html/nassima/assets/images/logo.png`

### 📰 Changer les photos d'actualités

```
/var/www/public_html/nassima/assets/images/news-1.jpg
/var/www/public_html/nassima/assets/images/news-2.jpg
/var/www/public_html/nassima/assets/images/news-3.jpg
```

### 🎯 Changer la photo "À propos"

```
/var/www/public_html/nassima/assets/images/about.jpg
```

### ✏️ Changer les textes du site

Tout le texte est dans **3 fichiers**, un par langue :

```
/var/www/public_html/nassima/lang/fr.php   ← Français
/var/www/public_html/nassima/lang/en.php   ← Anglais
/var/www/public_html/nassima/lang/ar.php   ← Arabe
```

Ouvrez-les avec un éditeur et modifiez le texte entre les guillemets.

**⚠️ Règles importantes pour éditer les fichiers PHP :**
- Ne supprimez JAMAIS les virgules à la fin des lignes
- Ne supprimez pas les crochets `[` et `]`
- Si votre texte contient une apostrophe `l'école`, utilisez des guillemets
  doubles : `"l'école"`
- Gardez l'encodage UTF-8

### 🎨 Changer les couleurs

Ouvrez `/var/www/public_html/nassima/assets/css/style.css` et modifiez les
premières lignes :

```css
:root {
  --color-primary: #0a2a5e;       ← bleu principal
  --color-accent: #f37021;        ← orange
  ...
}
```

## 🛠️ Dépannage

### Page blanche après installation

1. Vérifiez que PHP est installé : `php -v`
2. Vérifiez qu'il n'y a pas d'ancien `index.html` qui traîne :
   ```bash
   ls /var/www/public_html/nassima/index.*
   ```
   Vous devez voir UNIQUEMENT `index.php`. Si un `index.html` existe,
   supprimez-le : `sudo rm /var/www/public_html/nassima/index.html`
3. Redémarrez Apache : `sudo systemctl restart apache2`
4. Consultez les erreurs : `sudo tail -30 /var/log/apache2/error.log`

### Le compteur de visites ne fonctionne pas

```bash
sudo chmod -R 775 /var/www/public_html/nassima/data
sudo chown -R www-data:www-data /var/www/public_html/nassima/data
```

### Mes modifications ne s'affichent pas

- Grâce au versionnement automatique, cela ne devrait PLUS jamais arriver.
- Si ça arrive quand même : `sudo systemctl restart apache2`
- Et dans votre navigateur : `Ctrl + Shift + R`

### Le formulaire de contact ne fonctionne pas

PHP doit être configuré pour envoyer des emails. Installez sendmail :

```bash
sudo apt install sendmail
sudo systemctl restart apache2
```

Les messages sont aussi sauvegardés dans `data/messages.log` — vous pouvez
les consulter là même si l'envoi d'email ne fonctionne pas.

## 📧 Support

Pour toute question technique, consultez les logs Apache :
```bash
sudo tail -50 /var/log/apache2/error.log
```
