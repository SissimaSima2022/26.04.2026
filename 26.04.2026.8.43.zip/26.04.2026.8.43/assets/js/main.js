(function () {
  'use strict';

  // ======== HERO SLIDER ========
  var slides = document.querySelectorAll('.hero-slide');
  var dots = document.querySelectorAll('.hero-dot');
  var prevBtn = document.querySelector('.hero-nav-prev');
  var nextBtn = document.querySelector('.hero-nav-next');
  var current = 0;
  var autoplayTimer = null;

  function showSlide(i) {
    if (!slides.length) return;
    slides.forEach(function (s, idx) {
      s.classList.toggle('active', idx === i);
    });
    dots.forEach(function (d, idx) {
      d.classList.toggle('active', idx === i);
    });
    current = i;
  }

  function nextSlide() { showSlide((current + 1) % slides.length); }
  function prevSlide() { showSlide((current - 1 + slides.length) % slides.length); }

  function startAutoplay() {
    stopAutoplay();
    if (slides.length > 1) autoplayTimer = setInterval(nextSlide, 6000);
  }
  function stopAutoplay() {
    if (autoplayTimer) { clearInterval(autoplayTimer); autoplayTimer = null; }
  }

  if (slides.length) {
    if (nextBtn) nextBtn.addEventListener('click', function () { nextSlide(); startAutoplay(); });
    if (prevBtn) prevBtn.addEventListener('click', function () { prevSlide(); startAutoplay(); });
    dots.forEach(function (d, i) {
      d.addEventListener('click', function () { showSlide(i); startAutoplay(); });
    });

    // Pause autoplay on mouse hover over the hero
    var hero = document.querySelector('.hero');
    if (hero) {
      hero.addEventListener('mouseenter', stopAutoplay);
      hero.addEventListener('mouseleave', startAutoplay);
    }

    // Keyboard navigation (left / right arrows) when hero is visible
    document.addEventListener('keydown', function (e) {
      // only when user hasn't focused an input
      var tag = (document.activeElement && document.activeElement.tagName) || '';
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      // only when hero is in viewport
      var rect = slides[0].parentElement.getBoundingClientRect();
      if (rect.bottom < 0 || rect.top > window.innerHeight) return;

      if (e.key === 'ArrowLeft')  { prevSlide(); startAutoplay(); }
      if (e.key === 'ArrowRight') { nextSlide(); startAutoplay(); }
    });

    // Touch swipe support on mobile
    var touchStartX = 0;
    var touchEndX = 0;
    var heroElt = slides[0].parentElement;
    heroElt.addEventListener('touchstart', function (e) { touchStartX = e.changedTouches[0].screenX; }, { passive: true });
    heroElt.addEventListener('touchend', function (e) {
      touchEndX = e.changedTouches[0].screenX;
      var diff = touchEndX - touchStartX;
      if (Math.abs(diff) < 50) return;
      if (diff < 0) { nextSlide(); } else { prevSlide(); }
      startAutoplay();
    }, { passive: true });

    startAutoplay();
  }

  // ======== MOBILE NAVIGATION ========
  var toggle = document.getElementById('mobile-toggle');
  var mobileNav = document.getElementById('nav-mobile');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', function () {
      mobileNav.classList.toggle('open');
    });
  }

  // ======== ANIMATED VISITOR COUNT ========
  var counter = document.querySelector('.visitor-count');
  if (counter) {
    var target = parseInt(counter.textContent.replace(/[^0-9]/g, ''), 10);
    if (!isNaN(target)) {
      var start = Math.max(target - 120, 0);
      counter.textContent = start.toLocaleString();
      var step = function () {
        start += Math.ceil((target - start) / 12);
        if (start >= target) {
          counter.textContent = target.toLocaleString();
          return;
        }
        counter.textContent = start.toLocaleString();
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }
  }

  // ======== ANIMATED STAT COUNTERS ========
  var statNumbers = document.querySelectorAll('.stat-number');
  if (statNumbers.length && 'IntersectionObserver' in window) {
    var animateNumber = function (el) {
      var target = parseInt(el.getAttribute('data-target'), 10);
      if (isNaN(target) || target <= 0) return;
      var duration = 1800;
      var start = performance.now();
      var step = function (now) {
        var progress = Math.min((now - start) / duration, 1);
        // ease-out cubic
        var eased = 1 - Math.pow(1 - progress, 3);
        var current = Math.floor(target * eased);
        el.textContent = current.toLocaleString();
        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = target.toLocaleString();
        }
      };
      requestAnimationFrame(step);
    };

    var statObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateNumber(entry.target);
          statObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });

    statNumbers.forEach(function (el) { statObserver.observe(el); });
  }

  // ======== NEWSLETTER FORM (client-side success feedback) ========
  var newsletterForms = document.querySelectorAll('.newsletter-form');
  newsletterForms.forEach(function (form) {
    form.addEventListener('submit', function (e) {
      // If subscribe.php doesn't exist we can still handle client-side
      var input = form.querySelector('input[type="email"]');
      if (!input || !input.value) return;
    });
  });
})();
