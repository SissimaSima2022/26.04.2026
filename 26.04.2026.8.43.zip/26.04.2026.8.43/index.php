<?php
// ============================================================
// ENSTSA — Main router
// ============================================================
require __DIR__ . '/includes/config.php';

$page = $_GET['page'] ?? 'home';

// Sanitize: only allow letters, digits, slash, dash, underscore
if (!preg_match('#^[a-z0-9/_-]+$#i', $page)) {
    $page = 'home';
}

// Page title used in the <title> tag
$page_titles = [
    'home'    => $T['school_short'],
    'contact' => $T['contact']['title'],
];
$page_title = $page_titles[$page] ?? ($T['pages'][$page]['title'] ?? $T['generic']['page_title']);

require __DIR__ . '/includes/header.php';

if ($page === 'home') {
    require __DIR__ . '/pages/home.php';
} elseif ($page === 'contact') {
    require __DIR__ . '/pages/contact.php';
} elseif (isset($T['pages'][$page])) {
    require __DIR__ . '/pages/generic.php';
} else {
    http_response_code(404);
    require __DIR__ . '/pages/generic.php';
}

require __DIR__ . '/includes/footer.php';
