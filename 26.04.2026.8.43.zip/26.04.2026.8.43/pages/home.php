<?php if (!defined('BASE_URL')) exit; ?>
<!-- HERO SLIDER -->
<section class="hero">
    <?php foreach ($T['hero']['slides'] as $i => $slide): ?>
        <div class="hero-slide <?= $i === 0 ? 'active' : '' ?>">
            <img src="<?= asset('images/campus-' . ($i + 1) . '.jpg') ?>" alt="">
        </div>
    <?php endforeach; ?>

    <div class="hero-content">
        <div class="container">
            <?php foreach ($T['hero']['slides'] as $i => $slide): ?>
                <div class="hero-text" style="<?= $i === 0 ? '' : 'display:none;' ?>" data-hero-text="<?= $i ?>">
                    <div class="hero-badge">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <?= e($T['hero']['badge']) ?>
                    </div>
                    <h1 class="hero-title"><?= e($slide['title']) ?></h1>
                    <p class="hero-desc"><?= e($slide['desc']) ?></p>
                    <a href="<?= page_url('school/about') ?>" class="hero-cta">
                        <?= e($T['hero']['read_more']) ?>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <button class="hero-nav-btn hero-nav-prev" aria-label="Previous"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
    <button class="hero-nav-btn hero-nav-next" aria-label="Next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg></button>

    <div class="hero-dots">
        <?php foreach ($T['hero']['slides'] as $i => $_): ?>
            <button class="hero-dot <?= $i === 0 ? 'active' : '' ?>" aria-label="Slide <?= $i + 1 ?>"></button>
        <?php endforeach; ?>
    </div>
</section>

<!-- ABOUT SECTION -->
<section class="about-section">
    <div class="container">
        <div class="about-grid">
            <div class="about-img-wrap">
                <img src="<?= asset('images/about.jpg') ?>" alt="">
                <div class="about-badge">
                    <div class="about-badge-year"><?= e($T['about']['badge_year']) ?></div>
                    <div class="about-badge-text"><?= e($T['about']['badge_text']) ?></div>
                </div>
            </div>
            <div>
                <div class="section-tag"><?= e($T['about']['tag']) ?></div>
                <h2 class="section-title"><?= e($T['about']['title']) ?></h2>
                <p class="section-body" style="margin-bottom: 2rem;"><?= e($T['about']['body']) ?></p>
                <a href="<?= page_url('school/about') ?>" class="btn-outline">
                    <?= e($T['about']['cta']) ?>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- STATISTICS SECTION -->
<section class="stats-section">
    <div class="stats-bg"></div>
    <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.08) 1px,transparent 1px);background-size:28px 28px;opacity:.4;z-index:-1;"></div>
    <div class="container">
        <div class="stats-header">
            <div class="section-tag" style="color:rgba(255,255,255,.7)"><?= e($T['stats']['tag']) ?></div>
            <h2 class="section-title" style="color:white"><?= e($T['stats']['title']) ?></h2>
            <p class="section-body" style="color:rgba(255,255,255,.8)"><?= e($T['stats']['body']) ?></p>
        </div>
        <div class="stats-grid">
            <?php
            $stat_cards = [
                ['n' => 541, 'label' => $T['stats_section']['students']['label'], 'sub' => $T['stats_section']['students']['sub'], 'icon' => 'students'],
                ['n' => 65,  'label' => $T['stats_section']['teachers']['label'], 'sub' => $T['stats_section']['teachers']['sub'], 'icon' => 'teachers'],
                ['n' => 48,  'label' => $T['stats_section']['employees']['label'], 'sub' => $T['stats_section']['employees']['sub'], 'icon' => 'employees'],
                ['n' => 32,  'label' => $T['stats_section']['rooms']['label'], 'sub' => $T['stats_section']['rooms']['sub'], 'icon' => 'rooms'],
            ];
            $stat_icons = [
                'students' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
                'teachers' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
                'employees' => '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
                'rooms' => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
            ];
            $stat_gradients = [
                'students' => 'linear-gradient(135deg, #061b3f, #0a2a5e, #1e4a8f)',
                'teachers' => 'linear-gradient(135deg, #1e4a8f, #3b82f6)',
                'employees' => 'linear-gradient(135deg, #b45309, #f37021)',
                'rooms' => 'linear-gradient(135deg, #0f766e, #14b8a6)',
            ];
            foreach ($stat_cards as $i => $sc): ?>
            <div class="stat-card" style="cursor:pointer;animation-delay:<?= $i * 0.12 ?>s">
                <div class="stat-icon" style="background:<?= $stat_gradients[$sc['icon']] ?>">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?= $stat_icons[$sc['icon']] ?></svg>
                </div>
                <div class="stat-number" data-target="<?= $sc['n'] ?>"><?= $sc['n'] ?></div>
                <div class="stat-label"><?= e($sc['label']) ?></div>
                <div class="stat-sub"><?= e($sc['sub']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- COOPERATION SECTION -->
<section class="coop-section">
    <div class="coop-bg"></div>
    <div class="coop-pattern"></div>
    <div class="container">
        <div class="coop-header">
            <div class="section-tag"><?= e($T['coop']['tag']) ?></div>
            <h2 class="section-title"><?= e($T['coop']['title']) ?></h2>
            <p class="section-body"><?= e($T['coop']['body']) ?></p>
        </div>
        <div class="partners-grid">
            <?php
            $partners = [
                ['key' => 'nesda', 'name' => 'NESDA', 'url' => 'https://nesda.dz', 'color' => '#1a5490'],
                ['key' => 'usthb', 'name' => 'USTHB', 'url' => 'https://www.usthb.dz', 'color' => '#b62a2a'],
                ['key' => 'cerist', 'name' => 'CERIST', 'url' => 'https://www.cerist.dz', 'color' => '#0f766e'],
                ['key' => 'crti', 'name' => 'CRTI', 'url' => 'https://www.crti.dz', 'color' => '#b45309'],
            ];
            foreach ($partners as $p): ?>
                <a href="<?= e($p['url']) ?>" target="_blank" rel="noopener" class="partner-card" style="--partner-color: <?= e($p['color']) ?>">
                    <div class="partner-badge"><?= substr($p['name'], 0, 2) ?></div>
                    <div class="partner-name"><?= e($p['name']) ?></div>
                    <div class="partner-desc"><?= e($T['partners'][$p['key']]) ?></div>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="coop-cta">
            <a href="<?= page_url('school/partnerships') ?>" class="btn-accent">
                <?= e($T['coop']['cta']) ?>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
    </div>
</section>

<!-- NEWS SECTION -->
<section>
    <div class="container">
        <div class="news-header">
            <div>
                <div class="section-tag"><?= e($T['news']['tag']) ?></div>
                <h2 class="section-title"><?= e($T['news']['title']) ?></h2>
            </div>
            <a href="<?= page_url('announcements/offers') ?>" class="link-primary">
                <?= e($T['news']['cta']) ?>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
        <div class="news-grid">
            <?php foreach ($T['news']['items'] as $i => $n): ?>
                <article class="news-card">
                    <div class="news-img">
                        <img src="<?= asset('images/news-' . ($i + 1) . '.jpg') ?>" alt="">
                        <div class="news-tag">News</div>
                    </div>
                    <div class="news-body">
                        <div class="news-date">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                            <?= e($T['news']['dates'][$i]) ?>
                        </div>
                        <h3 class="news-title"><?= e($n['t']) ?></h3>
                        <p class="news-desc"><?= e($n['d']) ?></p>
                        <a href="<?= page_url('announcements/offers') ?>" class="link-arrow">
                            <?= e($T['generic']['read_more']) ?>
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- EVENTS CALENDAR -->
<section class="events-section">
    <div class="container">
        <div class="events-wrapper">
            <div class="events-header">
                <div>
                    <div class="section-tag"><?= e($T['events']['tag']) ?></div>
                    <h2 class="section-title"><?= e($T['events']['title']) ?></h2>
                </div>
                <a href="<?= page_url('campus/events') ?>" class="link-primary">
                    <?= e($T['news']['cta']) ?>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
            </div>
            <div class="events-list">
                <?php foreach ($T['events']['list'] as $ev): ?>
                    <div class="event-item">
                        <div class="event-date">
                            <div class="event-day"><?= str_pad((string)$ev['day'], 2, '0', STR_PAD_LEFT) ?></div>
                            <div class="event-month"><?= e($T['events']['months'][$ev['month']]) ?></div>
                        </div>
                        <div class="event-info">
                            <div class="event-title"><?= e($ev['title']) ?></div>
                            <div class="event-place">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                <?= e($ev['place']) ?>
                            </div>
                        </div>
                        <svg class="event-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<script>
(function(){
  // Sync hero text with slide index
  var texts = document.querySelectorAll('[data-hero-text]');
  var slides = document.querySelectorAll('.hero-slide');
  var observer = new MutationObserver(function(){
    slides.forEach(function(s, i){
      if (s.classList.contains('active')) {
        texts.forEach(function(t){ t.style.display = 'none'; });
        if (texts[i]) texts[i].style.display = 'block';
      }
    });
  });
  slides.forEach(function(s){ observer.observe(s, { attributes: true, attributeFilter: ['class'] }); });
})();
</script>
