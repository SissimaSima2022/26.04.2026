<?php
if (!defined('BASE_URL')) exit;
$slug = $_GET['page'] ?? '';
$page_data = $T['pages'][$slug] ?? ['title' => $T['generic']['page_title'], 'intro' => $T['generic']['coming']];
$parts = explode('/', $slug);
$section_name = ucfirst($parts[0] ?? '');
$has_body = !empty($page_data['body']);
?>
<section class="page-hero">
    <div class="page-hero-glow"></div>
    <div class="container">
        <div class="breadcrumb">
            <a href="<?= url('') ?>">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                <?= e($T['generic']['home']) ?>
            </a>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
            <span><?= e($section_name) ?></span>
        </div>
        <h1 class="page-title"><?= e($page_data['title']) ?></h1>
        <p class="page-intro"><?= e($page_data['intro']) ?></p>
    </div>
</section>

<section class="page-body">
    <div class="container">
        <div class="page-card">
            <?php if ($has_body): ?>
                <?php
                // Split body by double newlines into paragraphs, preserve single newlines inside paragraphs.
                $paragraphs = preg_split('/\n\s*\n/', trim($page_data['body']));
                foreach ($paragraphs as $p):
                    $p = trim($p);
                    if ($p === '') continue;
                    // If the paragraph looks like a heading (short line ending without punctuation or starting with known patterns)
                    $firstLine = explode("\n", $p)[0];
                    $isHeading = (mb_strlen($firstLine) < 70
                                  && !str_contains($firstLine, '.')
                                  && !str_contains($firstLine, ':')
                                  && !str_starts_with($firstLine, '•')
                                  && !str_starts_with($firstLine, '–')
                                  && !preg_match('/^\d+\./', $firstLine)
                                  && count(explode("\n", $p)) > 1);
                ?>
                    <?php if ($isHeading): ?>
                        <h2 class="page-h2"><?= e($firstLine) ?></h2>
                        <?php
                        $rest = mb_substr($p, mb_strlen($firstLine));
                        $rest = ltrim($rest, "\n");
                        if ($rest !== ''): ?>
                            <p class="page-paragraph"><?= nl2br(e($rest)) ?></p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="page-paragraph"><?= nl2br(e($p)) ?></p>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="page-card-text"><?= e($page_data['intro']) ?></p>
                <div class="page-callout">
                    <div class="page-callout-icon">✨</div>
                    <div class="page-callout-text"><?= e($T['generic']['coming']) ?></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
