<?php
/**
 * ENSTSA — Student Statistics Modal (included inline, triggered via JS)
 * Renders an invisible modal div; JS opens it when "Vie étudiante" is clicked.
 */
if (!defined('BASE_URL')) exit;

// ── Data ─────────────────────────────────────────────────────────────────────
$prep_years = [
    ['year' => '1st Year', 'enrolled' => 201, 'on_leave' => 14, 'registered' => 215],
    ['year' => '2nd Year', 'enrolled' => 196, 'on_leave' => 10, 'registered' => 206],
];
$prep_total = 421;

$spec_years = [
    ['year' => '1st Year', 'specialty' => 'Autonomous Embedded Systems Engineering',  'enrolled' => 38, 'on_leave' => 1, 'registered' => 39],
    ['year' => '2nd Year', 'specialty' => 'Robotics and Autonomous Systems Design',    'enrolled' => 37, 'on_leave' => 3, 'registered' => 40],
    ['year' => '3rd Year', 'specialty' => 'Navigation and Control of Unmanned Systems','enrolled' => 41, 'on_leave' => 0, 'registered' => 41],
];
$spec_total = 120;
$grand_total = $prep_total + $spec_total; // 541

// ── Labels (i18n) ─────────────────────────────────────────────────────────────
$lbl = [
    'title'      => $T['stats_modal']['title']      ?? 'Student Statistics',
    'ac_year'    => $T['stats_modal']['ac_year']    ?? 'Academic Year 2026–2027',
    'prep'       => $T['stats_modal']['prep']       ?? 'Preparatory Cycle',
    'spec'       => $T['stats_modal']['spec']       ?? 'Specialty Cycle',
    'prep_total' => $T['stats_modal']['prep_total'] ?? 'Total registered students in preparatory cycle',
    'spec_total' => $T['stats_modal']['spec_total'] ?? 'Total registered students in Specialty Cycle',
    'overview'   => $T['stats_modal']['overview']   ?? 'Overview',
    'enrolled'   => $T['stats_modal']['enrolled']   ?? 'Enrolled',
    'on_leave'   => $T['stats_modal']['on_leave']   ?? 'On Leave',
    'registered' => $T['stats_modal']['registered'] ?? 'Registered',
    'legend'     => $T['stats_modal']['legend']     ?? 'Legend',
    'total_all'  => $T['stats_modal']['total_all']  ?? 'Total Students',
];
?>

<!-- ============================================================
     STUDENT STATS MODAL
     ============================================================ -->
<div id="student-stats-modal" role="dialog" aria-modal="true" aria-label="<?= e($lbl['title']) ?>"
     style="display:none; position:fixed; inset:0; z-index:9998;">

    <!-- Backdrop -->
    <div id="ssm-backdrop"
         style="position:absolute; inset:0; background:rgba(6,27,63,0.72); backdrop-filter:blur(4px);"
         onclick="closeStudentStats()"></div>

    <!-- Panel -->
    <div id="ssm-panel"
         style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%) scale(0.94);
                width:min(960px,96vw); max-height:90vh; overflow-y:auto;
                background:#f4f8fc; border-radius:1.25rem;
                box-shadow:0 40px 80px -20px rgba(6,27,63,0.5);
                opacity:0; transition:opacity 0.28s ease, transform 0.28s cubic-bezier(.16,1,.3,1);">

        <!-- ── HEADER ── -->
        <div style="background:linear-gradient(135deg,#061b3f 0%,#0a2a5e 60%,#1e4a8f 100%);
                    border-radius:1.25rem 1.25rem 0 0; padding:1.5rem 2rem;
                    display:flex; align-items:center; justify-content:space-between;
                    position:relative; overflow:hidden; gap:1rem; flex-wrap:wrap;">
            <!-- grid pattern -->
            <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.06) 1px,transparent 1px);background-size:24px 24px;pointer-events:none;"></div>

            <!-- Title -->
            <div style="position:relative;display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:.75rem;background:rgba(243,112,33,.25);border:1px solid rgba(243,112,33,.4);display:flex;align-items:center;justify-content:center;">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f37021" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                </div>
                <div>
                    <div style="font-family:var(--font-display);font-weight:700;font-size:1.25rem;color:white;"><?= e($lbl['title']) ?></div>
                    <div style="font-size:.75rem;color:rgba(255,255,255,.6);margin-top:2px;"><?= e($lbl['ac_year']) ?></div>
                </div>
            </div>

            <!-- Grand total badge -->
            <div style="position:relative;background:rgba(243,112,33,.15);border:1px solid rgba(243,112,33,.35);border-radius:.75rem;padding:.5rem 1.25rem;text-align:center;">
                <div class="ssm-counter" data-target="<?= $grand_total ?>"
                     style="font-family:var(--font-display);font-size:2rem;font-weight:800;color:#f37021;line-height:1;">0</div>
                <div style="font-size:.6rem;text-transform:uppercase;letter-spacing:.12em;color:rgba(255,255,255,.5);margin-top:2px;"><?= e($lbl['total_all']) ?></div>
            </div>

            <!-- Close -->
            <button onclick="closeStudentStats()"
                    style="position:relative;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:white;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>

        <!-- ── BODY ── -->
        <div style="padding:1.5rem 2rem 2rem; display:flex; flex-direction:column; gap:1.5rem;">

            <!-- Overview row: donut + summary cards -->
            <div style="display:grid; grid-template-columns:auto 1fr; gap:1.5rem; align-items:center;">

                <!-- Donut -->
                <div style="background:white;border-radius:1rem;padding:1.25rem 1.5rem;border:1px solid #dbe6f2;display:flex;flex-direction:column;align-items:center;gap:8px;">
                    <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:.15em;color:#5b6b85;margin-bottom:4px;"><?= e($lbl['overview']) ?></div>
                    <div style="position:relative;width:140px;height:140px;">
                        <?php
                        $r = 52; $cx = 70; $cy = 70;
                        $circ = 2 * M_PI * $r;
                        $prepDash = ($prep_total / $grand_total) * $circ;
                        $specDash = ($spec_total / $grand_total) * $circ;
                        ?>
                        <svg width="140" height="140" viewBox="0 0 140 140">
                            <circle cx="<?= $cx ?>" cy="<?= $cy ?>" r="<?= $r ?>" fill="none" stroke="#dbe6f2" stroke-width="16"/>
                            <circle class="ssm-arc-prep" cx="<?= $cx ?>" cy="<?= $cy ?>" r="<?= $r ?>"
                                    fill="none" stroke="#0a2a5e" stroke-width="16"
                                    stroke-dasharray="0 <?= $circ ?>"
                                    data-dash="<?= $prepDash ?>" data-total="<?= $circ ?>"
                                    stroke-linecap="round"
                                    style="transform-origin:70px 70px;transform:rotate(-90deg);transition:stroke-dasharray 1.2s ease-out .1s;"/>
                            <circle class="ssm-arc-spec" cx="<?= $cx ?>" cy="<?= $cy ?>" r="<?= $r ?>"
                                    fill="none" stroke="#f37021" stroke-width="16"
                                    stroke-dasharray="0 <?= $circ ?>"
                                    stroke-dashoffset="-<?= $prepDash ?>"
                                    data-dash="<?= $specDash ?>" data-total="<?= $circ ?>"
                                    stroke-linecap="round"
                                    style="transform-origin:70px 70px;transform:rotate(-90deg);transition:stroke-dasharray 1.2s ease-out .4s;"/>
                        </svg>
                        <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;">
                            <span class="ssm-counter" data-target="<?= $grand_total ?>"
                                  style="font-family:var(--font-display);font-size:1.5rem;font-weight:800;color:#0a2a5e;line-height:1;">0</span>
                            <span style="font-size:.6rem;text-transform:uppercase;letter-spacing:.1em;color:#5b6b85;margin-top:2px;">Total</span>
                        </div>
                    </div>
                    <!-- legend -->
                    <div style="display:flex;gap:16px;">
                        <div style="display:flex;align-items:center;gap:6px;">
                            <span style="width:10px;height:10px;border-radius:2px;background:#0a2a5e;display:inline-block;"></span>
                            <span style="font-size:.7rem;color:#5b6b85;">Prep.</span>
                            <span style="font-size:.7rem;font-weight:700;color:#0a2a5e;"><?= $prep_total ?></span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;">
                            <span style="width:10px;height:10px;border-radius:2px;background:#f37021;display:inline-block;"></span>
                            <span style="font-size:.7rem;color:#5b6b85;">Spec.</span>
                            <span style="font-size:.7rem;font-weight:700;color:#f37021;"><?= $spec_total ?></span>
                        </div>
                    </div>
                </div>

                <!-- Summary cards -->
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <!-- Prep card -->
                    <div style="background:linear-gradient(135deg,#0a2a5e,#1e4a8f);border-radius:1rem;padding:1.25rem;color:white;display:flex;flex-direction:column;gap:8px;">
                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:.15em;color:rgba(255,255,255,.6);"><?= e($lbl['prep']) ?></div>
                        <div class="ssm-counter" data-target="<?= $prep_total ?>"
                             style="font-family:var(--font-display);font-size:2.75rem;font-weight:800;line-height:1;color:white;">0</div>
                        <div style="font-size:.7rem;color:rgba(255,255,255,.65);line-height:1.4;"><?= e($lbl['prep_total']) ?></div>
                        <div style="display:flex;gap:8px;margin-top:4px;">
                            <?php foreach ($prep_years as $y): ?>
                            <div style="flex:1;background:rgba(255,255,255,.1);border-radius:.5rem;padding:.4rem .6rem;text-align:center;">
                                <div style="font-size:.6rem;color:rgba(255,255,255,.55);"><?= e($y['year']) ?></div>
                                <div style="font-weight:700;font-size:.9rem;"><?= $y['registered'] ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <!-- Spec card -->
                    <div style="background:linear-gradient(135deg,#b45309,#f37021);border-radius:1rem;padding:1.25rem;color:white;display:flex;flex-direction:column;gap:8px;">
                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:.15em;color:rgba(255,255,255,.6);"><?= e($lbl['spec']) ?></div>
                        <div class="ssm-counter" data-target="<?= $spec_total ?>"
                             style="font-family:var(--font-display);font-size:2.75rem;font-weight:800;line-height:1;color:white;">0</div>
                        <div style="font-size:.7rem;color:rgba(255,255,255,.65);line-height:1.4;"><?= e($lbl['spec_total']) ?></div>
                        <div style="display:flex;gap:8px;margin-top:4px;">
                            <?php foreach ($spec_years as $y): ?>
                            <div style="flex:1;background:rgba(255,255,255,.1);border-radius:.5rem;padding:.4rem .6rem;text-align:center;">
                                <div style="font-size:.6rem;color:rgba(255,255,255,.55);"><?= e($y['year']) ?></div>
                                <div style="font-weight:700;font-size:.9rem;"><?= $y['registered'] ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ── Preparatory Cycle detail ── -->
            <div>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:.875rem;">
                    <div style="width:4px;height:20px;background:#0a2a5e;border-radius:99px;"></div>
                    <h3 style="font-family:var(--font-display);font-weight:700;font-size:1rem;color:#0a2a5e;"><?= e($lbl['prep']) ?></h3>
                    <div style="flex:1;height:1px;background:#dbe6f2;"></div>
                    <span style="background:#0a2a5e;color:white;border-radius:999px;padding:.2rem .75rem;font-size:.75rem;font-weight:700;"><?= $prep_total ?></span>
                </div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:.875rem;">
                    <?php foreach ($prep_years as $y): ?>
                    <div style="background:white;border:1px solid #dbe6f2;border-left:4px solid #0a2a5e;border-radius:.75rem;padding:1rem 1.25rem;">
                        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px;">
                            <div style="font-family:var(--font-display);font-weight:700;font-size:.9rem;color:#0a2a5e;"><?= e($y['year']) ?></div>
                            <div style="background:#0a2a5e;color:white;border-radius:.5rem;padding:.2rem .6rem;font-size:.8rem;font-weight:800;"><?= $y['registered'] ?></div>
                        </div>
                        <?php
                        $max = 220;
                        $bars = [
                            ['label' => $lbl['enrolled'],   'val' => $y['enrolled'],   'color' => '#0a2a5e'],
                            ['label' => $lbl['on_leave'],   'val' => $y['on_leave'],   'color' => '#f37021'],
                            ['label' => $lbl['registered'], 'val' => $y['registered'], 'color' => '#1e4a8f'],
                        ];
                        foreach ($bars as $b):
                            $pct = round(($b['val'] / $max) * 100);
                        ?>
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                            <span style="font-size:.65rem;color:#5b6b85;width:60px;flex-shrink:0;"><?= e($b['label']) ?></span>
                            <div style="flex:1;height:8px;background:#dbe6f2;border-radius:99px;overflow:hidden;">
                                <div class="ssm-bar" data-pct="<?= $pct ?>"
                                     style="height:100%;background:<?= $b['color'] ?>;border-radius:99px;width:0;transition:width .9s ease-out .2s;"></div>
                            </div>
                            <span style="font-size:.7rem;font-weight:700;color:<?= $b['color'] ?>;width:28px;text-align:right;"><?= $b['val'] ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ── Specialty Cycle detail ── -->
            <div>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:.875rem;">
                    <div style="width:4px;height:20px;background:#f37021;border-radius:99px;"></div>
                    <h3 style="font-family:var(--font-display);font-weight:700;font-size:1rem;color:#c2510f;"><?= e($lbl['spec']) ?></h3>
                    <div style="flex:1;height:1px;background:#dbe6f2;"></div>
                    <span style="background:#f37021;color:white;border-radius:999px;padding:.2rem .75rem;font-size:.75rem;font-weight:700;"><?= $spec_total ?></span>
                </div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:.875rem;">
                    <?php foreach ($spec_years as $y): ?>
                    <div style="background:white;border:1px solid #dbe6f2;border-left:4px solid #f37021;border-radius:.75rem;padding:1rem 1.25rem;">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:10px;">
                            <div>
                                <div style="font-family:var(--font-display);font-weight:700;font-size:.9rem;color:#f37021;"><?= e($y['year']) ?></div>
                                <div style="font-size:.7rem;color:#5b6b85;margin-top:2px;line-height:1.3;"><?= e($y['specialty']) ?></div>
                            </div>
                            <div style="background:#f37021;color:white;border-radius:.5rem;padding:.2rem .6rem;font-size:.8rem;font-weight:800;flex-shrink:0;"><?= $y['registered'] ?></div>
                        </div>
                        <?php
                        $max2 = 50;
                        $bars2 = [
                            ['label' => $lbl['enrolled'],   'val' => $y['enrolled'],   'color' => '#0a2a5e'],
                            ['label' => $lbl['on_leave'],   'val' => $y['on_leave'],   'color' => '#f37021'],
                            ['label' => $lbl['registered'], 'val' => $y['registered'], 'color' => '#1e4a8f'],
                        ];
                        foreach ($bars2 as $b):
                            $pct2 = round(($b['val'] / $max2) * 100);
                        ?>
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                            <span style="font-size:.65rem;color:#5b6b85;width:60px;flex-shrink:0;"><?= e($b['label']) ?></span>
                            <div style="flex:1;height:8px;background:#dbe6f2;border-radius:99px;overflow:hidden;">
                                <div class="ssm-bar" data-pct="<?= $pct2 ?>"
                                     style="height:100%;background:<?= $b['color'] ?>;border-radius:99px;width:0;transition:width .9s ease-out .2s;"></div>
                            </div>
                            <span style="font-size:.7rem;font-weight:700;color:<?= $b['color'] ?>;width:28px;text-align:right;"><?= $b['val'] ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Legend -->
            <div style="background:white;border-radius:.75rem;padding:.875rem 1.25rem;border:1px solid #dbe6f2;display:flex;flex-wrap:wrap;gap:1.5rem;align-items:center;">
                <span style="font-size:.7rem;color:#5b6b85;font-weight:600;text-transform:uppercase;letter-spacing:.1em;"><?= e($lbl['legend']) ?></span>
                <?php foreach ([
                    ['#0a2a5e', $lbl['enrolled']],
                    ['#f37021', $lbl['on_leave']],
                    ['#1e4a8f', $lbl['registered'].' (total)'],
                ] as [$col, $lab]): ?>
                <div style="display:flex;align-items:center;gap:6px;">
                    <span style="width:12px;height:12px;border-radius:3px;background:<?= $col ?>;display:inline-block;flex-shrink:0;"></span>
                    <span style="font-size:.75rem;color:#5b6b85;"><?= e($lab) ?></span>
                </div>
                <?php endforeach; ?>
            </div>

        </div><!-- /body -->
    </div><!-- /panel -->
</div><!-- /modal -->

<script>
(function(){
    function openStudentStats(){
        var modal = document.getElementById('student-stats-modal');
        var panel = document.getElementById('ssm-panel');
        modal.style.display = 'block';
        // Force reflow then animate in
        requestAnimationFrame(function(){
            requestAnimationFrame(function(){
                panel.style.opacity = '1';
                panel.style.transform = 'translate(-50%,-50%) scale(1)';
            });
        });
        // Animate counters
        modal.querySelectorAll('.ssm-counter').forEach(function(el){
            var target = parseInt(el.getAttribute('data-target'), 10);
            var duration = 1400;
            var startTime = performance.now();
            (function step(now){
                var progress = Math.min((now - startTime) / duration, 1);
                var eased = 1 - Math.pow(1 - progress, 3);
                el.textContent = Math.floor(target * eased).toString();
                if(progress < 1){ requestAnimationFrame(step); }
                else { el.textContent = target.toString(); }
            })(performance.now());
        });
        // Animate bars
        modal.querySelectorAll('.ssm-bar').forEach(function(el){
            var pct = el.getAttribute('data-pct');
            setTimeout(function(){ el.style.width = pct + '%'; }, 50);
        });
        // Animate arcs
        modal.querySelectorAll('.ssm-arc-prep, .ssm-arc-spec').forEach(function(el){
            var dash = parseFloat(el.getAttribute('data-dash'));
            var total = parseFloat(el.getAttribute('data-total'));
            setTimeout(function(){
                el.style.strokeDasharray = dash + ' ' + total;
            }, 50);
        });
        document.body.style.overflow = 'hidden';
    }

    function closeStudentStats(){
        var modal = document.getElementById('student-stats-modal');
        var panel = document.getElementById('ssm-panel');
        panel.style.opacity = '0';
        panel.style.transform = 'translate(-50%,-50%) scale(0.94)';
        setTimeout(function(){ modal.style.display = 'none'; }, 300);
        document.body.style.overflow = '';
    }

    // Expose globally
    window.openStudentStats  = openStudentStats;
    window.closeStudentStats = closeStudentStats;

    // Escape key
    document.addEventListener('keydown', function(e){
        if(e.key === 'Escape') closeStudentStats();
    });
})();
</script>
