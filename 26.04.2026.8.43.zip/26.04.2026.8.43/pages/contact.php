<?php
if (!defined('BASE_URL')) exit;
$sent = false;
$error = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $subject && $message) {
        $log_dir = __DIR__ . '/../data';
        if (!is_dir($log_dir)) @mkdir($log_dir, 0755, true);
        $line = '[' . date('Y-m-d H:i:s') . '] ' . str_replace(["\r", "\n"], ' ', "$name <$email> — $subject — $message") . PHP_EOL;
        @file_put_contents($log_dir . '/messages.log', $line, FILE_APPEND | LOCK_EX);
        // Attempt to send email (may fail on local/dev servers)
        @mail('contact@enstsa.edu.dz', 'Website Contact: ' . $subject, "From: $name <$email>\n\n$message", 'From: noreply@enstsa.edu.dz');
        $sent = true;
    } else {
        $error = true;
    }
}
?>
<section class="contact-page">
    <div class="container">
        <div class="contact-grid">
            <div class="contact-info">
                <div>
                    <div class="section-tag">Contact</div>
                    <h1 class="section-title" style="font-size: 2.5rem;"><?= e($T['contact']['title']) ?></h1>
                    <p class="section-body"><?= e($T['contact']['sub']) ?></p>
                </div>
                <div>
                    <div class="contact-card">
                        <div class="contact-card-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
                        <div class="contact-card-text" style="align-self:center;"><?= e($T['footer']['address']) ?></div>
                    </div>
                    <div class="contact-card" style="margin-top: 0.75rem;">
                        <div class="contact-card-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div>
                        <div class="contact-card-text" style="align-self:center;">contact@enstsa.edu.dz</div>
                    </div>
                    <div class="contact-card" style="margin-top: 0.75rem;">
                        <div class="contact-card-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div>
                        <div class="contact-card-text" style="align-self:center;"><?= e($T['contact']['phone']) ?></div>
                    </div>
                </div>
                <iframe class="contact-map" src="https://www.google.com/maps?q=Mahelma+Sidi+Abdellah+Algiers&output=embed" loading="lazy" title="ENSTSA Map"></iframe>
            </div>

            <form method="post" class="contact-form">
                <?php if ($sent): ?>
                    <div class="form-success">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <?= e($T['contact']['success']) ?>
                    </div>
                <?php elseif ($error): ?>
                    <div class="form-success" style="background:#fef2f2;color:#b91c1c;border-color:#fecaca;">
                        <?= e($T['contact']['error']) ?>
                    </div>
                <?php endif; ?>
                <div class="form-row">
                    <label class="form-group">
                        <span class="form-label"><?= e($T['contact']['name']) ?></span>
                        <input type="text" name="name" class="form-input" required>
                    </label>
                    <label class="form-group">
                        <span class="form-label"><?= e($T['contact']['email']) ?></span>
                        <input type="email" name="email" class="form-input" required>
                    </label>
                </div>
                <label class="form-group">
                    <span class="form-label"><?= e($T['contact']['subject']) ?></span>
                    <input type="text" name="subject" class="form-input" required>
                </label>
                <label class="form-group">
                    <span class="form-label"><?= e($T['contact']['message']) ?></span>
                    <textarea name="message" rows="6" class="form-textarea" required></textarea>
                </label>
                <button type="submit" class="form-submit">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                    <?= e($T['contact']['send']) ?>
                </button>
            </form>
        </div>
    </div>
</section>
